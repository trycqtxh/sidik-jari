<template>
    <div id="root">
        <template>
            <div class="container main-container">
                <!--<pre>{{userStore}}</pre>-->
                <router-view></router-view>
            </div>
        </template>
    </div>
</template>