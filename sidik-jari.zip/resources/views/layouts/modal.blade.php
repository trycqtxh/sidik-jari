<div class="modal" id="modal"  data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div id="load">

            </div>
        </div>
    </div>
</div>