<footer>
    <div class="container">
        <div class="pull-right hidden-xs"><strong>Version</strong> {{ config('app.version') }}</div>
        <strong>Copyright 2017</strong> All rights reserved
    </div>
</footer>